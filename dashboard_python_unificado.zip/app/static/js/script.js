/* ==========================================================
   Dashboard estatístico – lê qualquer planilha (Excel ou CSV)
   Nenhum dado vem embutido: tudo nasce do arquivo enviado.
   Índice: 1 Utilitários · 2 Estatística · 3 Análise das colunas
           4 Montagem dos gráficos · 5 Downloads · 6 Abas e upload
   ========================================================== */

/* ---------- 1. Utilitários ---------- */
const $=s=>document.querySelector(s),$$=id=>document.getElementById(id),
C={o:'#FF6A00',b:'#1E5AA8',k:'#000'},
PAL=[C.o,C.b,C.k,'#FFC299','#9DBBE8','#8A3A00','#0B2A52','#9CA3AF','#5C6F8F'],
f2=v=>typeof v=='number'?v.toLocaleString('pt-BR',{maximumFractionDigits:2}):v,
z2=x=>String(x).padStart(2,'0'),
sh=(s,n=30)=>s.length>n?s.slice(0,n-1)+'…':s,
R=[],ch={};let D=null,G=0,BS=[],BLK=[];
Chart.defaults.font.family='Segoe UI,Arial,sans-serif';Chart.defaults.color='#222';
Chart.register({id:'bg',beforeDraw(c){const x=c.ctx;x.save();x.globalCompositeOperation='destination-over';x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.restore()}});
const cnt=a=>{const m={};a.forEach(v=>String(v).split(', ').forEach(t=>m[t]=(m[t]||0)+1));return Object.entries(m).sort((x,y)=>y[1]-x[1])},
topN=a=>a.length>12?a.slice(0,11).concat([['Outros',a.slice(11).reduce((s,x)=>s+x[1],0)]]):a,
freqOf=c=>c.t=='c'?cnt(c.vals):c.cls.map(x=>[x.l,x.f]),
nn=a=>a.filter(x=>x!==null),
card=(id,t,body)=>$$('dash').insertAdjacentHTML('beforeend',`<section class="card" id="cd_${id}"><h2>${t}</h2><div id="bd_${id}">${body}</div><p class="na" id="na_${id}" hidden></p></section>`),
view=(id,ok,m)=>{$$('bd_'+id).hidden=!ok;$$('na_'+id).hidden=ok;if(!ok)$$('na_'+id).textContent=m},
cv=id=>`<div class="cv"><canvas id="${id}"></canvas></div>`,
mk=(id,cfg)=>ch[id]=new Chart($$(id),{...cfg,options:{responsive:true,maintainAspectRatio:false,...cfg.options}}),
setC=(id,lab,val)=>{const d=ch[id].data;d.labels=lab;d.datasets[0].data=val;ch[id].update()},
opts=(a,sel)=>a.map(([v,t])=>`<option value="${v}"${v==sel?' selected':''}>${sh(t,70)}</option>`).join('');

/* ---------- 2. Estatística ---------- */
const q=(s,p)=>{const i=(s.length-1)*p,l=Math.floor(i);return s[l]+(s[Math.ceil(i)]-s[l])*(i-l)};
function sU(a){if(!a.length)return null;const s=[...a].sort((x,y)=>x-y),n=s.length,m={};a.forEach(v=>m[v]=(m[v]||0)+1);const mx=Math.max(...Object.values(m));
return{n,min:s[0],max:s[n-1],mean:a.reduce((x,y)=>x+y,0)/n,q1:q(s,.25),med:q(s,.5),q3:q(s,.75),mode:Object.keys(m).filter(k=>m[k]==mx).map(k=>f2(+k)).join(' / ')}}
function sG(c){const n=c.reduce((s,x)=>s+x.f,0),p=k=>{let F=0;for(const x of c){if(x.f>0&&F+x.f>=k*n)return x.L+(k*n-F)/x.f*(x.U-x.L);F+=x.f}};
let i=0;c.forEach((x,j)=>{if(x.f>c[i].f)i=j});const x=c[i],d1=x.f-(c[i-1]?c[i-1].f:0),d2=x.f-(c[i+1]?c[i+1].f:0);
return{n,mean:c.reduce((s,x)=>s+x.f*(x.L+x.U)/2,0)/n,q1:p(.25),med:p(.5),q3:p(.75),mode:d1+d2?x.L+d1/(d1+d2)*(x.U-x.L):(x.L+x.U)/2,cls:x.l}}
const kpis=s=>[['Média',s.mean],['Mediana',s.med],['Moda',s.mode],['Q1 (25%)',s.q1],['Q2 (50%)',s.med],['Q3 (75%)',s.q3]].map(([a,b])=>`<div class="kpi"><small>${a}</small><b>${f2(b)}</b></div>`).join('');

/* ---------- 3. Análise automática das colunas ---------- */
const isNum=s=>/^-?\d+([.,]\d+)?$/.test(s),
isG=s=>/^(entre\s*)?\d+\s*(a|à|e|-|–)\s*\d+|^(\+|mais de|acima de|até|menos de)\s*\d+/i.test(s),
pDay=v=>{if(v instanceof Date)return`${v.getFullYear()}-${z2(v.getMonth()+1)}-${z2(v.getDate())}`;
if(typeof v=='number'&&v>20000){const d=new Date(Math.round((v-25569)*864e5));return`${d.getUTCFullYear()}-${z2(d.getUTCMonth()+1)}-${z2(d.getUTCDate())}`}
const s=String(v),m=s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/),i=s.match(/\d{4}-\d{2}-\d{2}/);return m?`${m[3]}-${z2(m[2])}-${z2(m[1])}`:i?i[0]:null};
/* faixas escritas ("Entre 1 a 15 minutos", "+8 horas") → classes com limites */
function gClasses(ls){const cs={};ls.forEach(s=>{const m=s.match(/\d+/g),lo=+m[0];cs[s]=m.length>1?[lo>0?lo-1:0,+m[1]]:[lo,null]});
const L=Object.entries(cs).sort((x,y)=>x[1][0]-y[1][0]),w=L.filter(x=>x[1][1]!=null).map(x=>x[1][1]-x[1][0]),dw=w.length?w[w.length-1]:10,rs=[],mid={};
L.forEach(([s,[lo,hi]])=>{if(hi==null)hi=lo+dw;const p=rs[rs.length-1];if(p&&lo>p.U)rs.push({l:`${p.U+1}–${lo}`,L:p.U,U:lo,f:0});
rs.push({l:s.replace(/entre\s*/i,'').replace(/\s+(a|à|e)\s+/,'–').replace(/\s*[a-zçãé]+\.?$/i,''),L:lo,U:hi,f:ls.filter(x=>x==s).length});mid[s]=(lo+hi)/2});return{rs,mid}}
/* números → classes (valores inteiros pequenos viram uma classe por valor; senão, regra de Sturges) */
function nClasses(v){const mn=Math.min(...v),mx=Math.max(...v),n=v.length,ints=v.every(Number.isInteger),r=[];
if(ints&&mx-mn<=20&&new Set(v).size<=12){for(let i=mn;i<=mx;i++)r.push({l:String(i),L:i-.5,U:i+.5,f:v.filter(x=>x==i).length});return r}
if(mx==mn)return[{l:f2(mn),L:mn-.5,U:mn+.5,f:n}];
const k=Math.max(4,Math.ceil(1+3.322*Math.log10(n)));let h=(mx-mn)/k;if(ints)h=Math.ceil(h);
for(let i=0;i<k;i++){const L=mn+i*h;if(ints&&i&&L>=mx)break;const U=ints?L+h:(i==k-1?mx:L+h);r.push({l:`${f2(L)}–${f2(U)}`,L,U,f:v.filter(x=>(i?x>L:x>=L)&&x<=U).length})}return r}
function analyze(a){
  const h=a[0].map(x=>String(x).trim()),rows=a.slice(1).filter(r=>r.some(v=>String(v).trim()!='')),n=rows.length;
  if(n<2)throw new Error('O arquivo precisa ter a linha de cabeçalhos e ao menos 2 linhas de dados.');
  const cols=[];let dates=null;
  h.forEach((name,i)=>{const raw=rows.map(r=>r[i]),s=raw.map(v=>String(v??'').trim()),ne=s.filter(x=>x!=='');
    if(!name||ne.length<n*.3)return;
    if(!dates&&/timestamp|carimbo|data|date/i.test(name)){const d=raw.map(pDay).filter(Boolean);if(d.length>=ne.length*.7){dates=d;return}}
    const un=new Set(ne).size;
    if(ne.filter(isNum).length>=ne.length*.8){const num=s.map(x=>isNum(x)?+x.replace(',','.'):null);cols.push({name,t:'n',num,cls:nClasses(nn(num))})}
    else if(ne.filter(isG).length>=ne.length*.6){const g=gClasses(ne.filter(isG));cols.push({name,t:'g',num:s.map(x=>g.mid[x]??null),cls:g.rs})}
    else if(un<=40&&(un<ne.length*.8||ne.length<10))cols.push({name,t:'c',vals:s.map(x=>x||'Não informado')});
  });
  if(!cols.length)throw new Error('Nenhuma coluna utilizável foi encontrada (categorias, números ou faixas).');
  const dm={};(dates||[]).forEach(d=>dm[d]=(dm[d]||0)+1);
  return{cols,n,days:Object.entries(dm).sort((x,y)=>x[0]<y[0]?-1:1)}}

/* ---------- 4. Montagem dos gráficos ---------- */
function boot(){
  R.length=0;Object.values(ch).forEach(c=>c.destroy());Object.keys(ch).forEach(k=>delete ch[k]);
  $$('dash').innerHTML='';$$('down').innerHTML='';
  if(!D){const m='<section class="card wide"><h2>Nenhum dado carregado</h2><p>Envie sua planilha (Excel ou CSV) na aba <b>Carregar dados</b> para ver os gráficos.</p></section>';$$('dash').innerHTML=m;$$('down').innerHTML=m;return}
  const K=D.cols,ix=t=>K.map((c,i)=>[i,c]).filter(x=>t.includes(x[1].t)),
  groups=[['Categorias','c'],['Numéricas (notas e contagens)','n'],['Faixas (intervalos de classe)','g']].filter(g=>ix(g[1]).length);
  $$('gf').innerHTML=groups.map(([t,k])=>`<optgroup label="${t}">${opts(ix(k).map(([i,c])=>[i,c.name]))}</optgroup>`).join('');
  G=ix('cng')[0][0];$$('gf').value=G;
  const NUM=ix('ng'),CAT=ix('c').filter(([i,c])=>new Set(c.vals).size<=25),dflt=CAT.length?CAT[0][0]:'';

  card('bar','Barras – frequência por categoria',cv('cbar'));
  mk('cbar',{type:'bar',data:{labels:[],datasets:[{label:'Respostas',data:[],backgroundColor:C.o}]},options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{y:{ticks:{callback(v){return sh(this.getLabelForValue(v),24)}}}}}});
  card('pie','Pizza – participação por categoria',cv('cpie'));
  mk('cpie',{type:'pie',data:{labels:[],datasets:[{data:[],backgroundColor:PAL,borderColor:'#fff',borderWidth:2}]},options:{plugins:{legend:{position:'right'}}}});
  card('dot','Ponto – relação entre duas variáveis numéricas',`<div class="ctl"><div class="fld"><label for="sx">Eixo X</label><select id="sx">${opts(NUM.map(([i,c])=>[i,c.name]))}</select></div><div class="fld"><label for="sy">Eixo Y</label><select id="sy">${opts(NUM.map(([i,c])=>[i,c.name]),NUM[1]?NUM[1][0]:'')}</select></div></div>${cv('cdot')}<p class="lg">Cada ponto é uma resposta (com pequeno deslocamento para não sobrepor). Faixas usam o ponto médio.</p>`);
  mk('cdot',{type:'scatter',data:{datasets:[{label:'Respostas',data:[],backgroundColor:C.b+'BB',pointRadius:6}]},options:{plugins:{legend:{display:false}},scales:{x:{title:{display:true,text:''}},y:{title:{display:true,text:''}}}}});
  card('line','Linha – evolução das respostas',cv('cline'));
  mk('cline',{type:'line',data:{labels:[],datasets:[{label:'',data:[],borderColor:C.o,backgroundColor:C.o+'33',fill:true,tension:0,pointBackgroundColor:C.k,pointRadius:4}]},options:{plugins:{legend:{display:false}}}});
  card('ogv','Ogiva – frequência acumulada (menor que)',cv('cogv'));
  mk('cogv',{type:'line',data:{labels:[],datasets:[{label:'Frequência acumulada',data:[],borderColor:C.b,backgroundColor:C.b+'26',fill:true,pointBackgroundColor:C.o,pointRadius:5,tension:0}]},options:{plugins:{legend:{display:false}},scales:{x:{title:{display:true,text:'Limite superior da classe'}},y:{title:{display:true,text:'Acumulada'}}}}});
  card('blk','Blockspot – média por grupo','<div id="blkb"></div><p class="lg">Quanto mais forte o laranja, maior a média daquele grupo dentro de cada coluna (cada coluna tem sua própria escala).</p>');
  card('box','Caixa (boxplot) – distribuição por grupo',`<div class="ctl"><div class="fld"><label for="sgrp">Agrupar por</label><select id="sgrp"><option value="">Sem agrupamento</option>${opts(CAT.map(([i,c])=>[i,c.name]),dflt)}</select></div></div>${cv('cbox')}<p class="lg">Laranja: Q1 a Q3 · linha preta: mediana · ponto azul: média · hastes: mínimo e máximo.</p>`);
  mk('cbox',{type:'bar',data:{labels:[],datasets:[{data:[],backgroundColor:'transparent',barPercentage:.5}]},
    options:{animation:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>{const s=BS[c.dataIndex];return[`n ${s.n} · Mín ${f2(s.min)} · Máx ${f2(s.max)}`,`Q1 ${f2(s.q1)} · Mediana ${f2(s.med)} · Q3 ${f2(s.q3)}`,`Média ${f2(s.mean)}`]}}}},scales:{y:{}}},
    plugins:[{id:'box',afterDatasetsDraw(c){const x=c.ctx,y=c.scales.y.getPixelForValue.bind(c.scales.y);
      c.getDatasetMeta(0).data.forEach((b,i)=>{const s=BS[i];if(!s)return;const w=b.width,l=b.x-w/2;x.save();x.strokeStyle=C.k;x.lineWidth=2;
      x.beginPath();x.moveTo(b.x,y(s.min));x.lineTo(b.x,y(s.max));x.moveTo(b.x-w/4,y(s.min));x.lineTo(b.x+w/4,y(s.min));x.moveTo(b.x-w/4,y(s.max));x.lineTo(b.x+w/4,y(s.max));x.stroke();
      x.fillStyle=C.o;x.fillRect(l,y(s.q3),w,Math.max(2,y(s.q1)-y(s.q3)));x.strokeRect(l,y(s.q3),w,Math.max(2,y(s.q1)-y(s.q3)));
      x.lineWidth=4;x.beginPath();x.moveTo(l,y(s.med));x.lineTo(l+w,y(s.med));x.stroke();
      x.fillStyle=C.b;x.beginPath();x.arc(b.x,y(s.mean),5,0,7);x.fill();x.restore()})}}]});
  card('su','Média, mediana, moda e quartis – sem intervalo de classe','<div class="kp" id="kun"></div><p class="lg">Valores individuais. Quartis por interpolação linear (método inclusivo). Moda com mais de um valor = multimodal.</p>');
  card('sg','Média, mediana, moda e quartis – com intervalo de classe','<div class="kp" id="kgr"></div><div id="tgr"></div><p class="lg">Média pelos pontos médios das classes; mediana e quartis por interpolação na classe; moda de Czuber.</p>');

  /* --- atualização conforme o filtro geral --- */
  const mean=a=>{a=nn(a);return a.length?a.reduce((s,x)=>s+x,0)/a.length:null};
  function dot(){const X=K[$$('sx').value],Y=K[$$('sy').value],p=[],rx=(Math.max(...nn(X.num))-Math.min(...nn(X.num)))||1,ry=(Math.max(...nn(Y.num))-Math.min(...nn(Y.num)))||1;
    X.num.forEach((x,i)=>{const y=Y.num[i];if(x!==null&&y!==null)p.push({x:x+(((i*37)%11)-5)/5*rx*.02,y:y+(((i*53)%9)-4)/4*ry*.02})});
    const c=ch.cdot;c.data.datasets[0].data=p;c.options.scales.x.title.text=sh(X.name,60);c.options.scales.y.title.text=sh(Y.name,60);c.update()}
  function blk(){const c=K[G],cc=c.t=='c'&&new Set(c.vals).size<=25?c:CAT.length?K[CAT[0][0]]:null,ns=K.filter(x=>x.t=='n').slice(0,10);
    if(!cc||!ns.length){BLK=[];return view('blk',false,'O blockspot precisa de ao menos uma coluna de categorias e uma numérica.')}
    view('blk',true);const m={};cc.vals.forEach((v,i)=>(m[v]=m[v]||[]).push(i));
    const gs=Object.entries(m).sort((a,b)=>b[1].length-a[1].length).slice(0,12).map(([k,ids])=>[k,ids]).concat([['Geral',null]]),
    rows=gs.map(([k,ids])=>[k,...ns.map(n=>{const v=mean(ids?ids.map(i=>n.num[i]):n.num);return v===null?null:+v.toFixed(2)})]);
    BLK=[['Grupo: '+cc.name,...ns.map(n=>n.name)]].concat(rows.map(r=>r.map(v=>v===null?'':v)));
    const cm=ns.map((_,j)=>{const a=rows.map(r=>r[j+1]).filter(v=>v!==null);return[Math.min(...a),Math.max(...a)]});
    $$('blkb').innerHTML=`<div class="bs" style="grid-template-columns:150px repeat(${ns.length},1fr)"><div class="h"></div>${ns.map(n=>`<div class="h" title="${n.name}">${sh(n.name.replace(/^\d+\.\s*/,''),22)}</div>`).join('')}${rows.map(r=>`<div class="r">${sh(r[0],28)}</div>`+r.slice(1).map((v,j)=>{const t=v===null?0:(v-cm[j][0])/((cm[j][1]-cm[j][0])||1);return`<div style="background:rgba(255,106,0,${(.08+t*.92).toFixed(2)});color:#000">${v===null?'–':f2(v)}</div>`}).join('')).join('')}</div>`}
  function box(){const c=K[G],gi=$$('sgrp').value,out=[['Geral',nn(c.num)]];
    if(gi!==''){const g=K[gi],m={};g.vals.forEach((v,i)=>{if(c.num[i]!==null)(m[v]=m[v]||[]).push(c.num[i])});Object.entries(m).sort((a,b)=>b[1].length-a[1].length).slice(0,12).forEach(e=>out.push(e))}
    BS=out.map(x=>sU(x[1])).filter(Boolean);const lab=out.filter(x=>x[1].length).map(x=>sh(x[0],22)),b=ch.cbox;
    b.data.labels=lab;b.data.datasets[0].data=BS.map(s=>s.max);b.options.scales.y.suggestedMin=Math.min(0,...BS.map(s=>s.min));b.options.scales.y.suggestedMax=Math.max(...BS.map(s=>s.max))*1.05;b.update()}
  function upd(){G=+$$('gf').value;const c=K[G],num=c.t!='c',fr=freqOf(c);
    setC('cbar',fr.map(x=>x[0]),fr.map(x=>x[1]));const p=topN(fr);setC('cpie',p.map(x=>x[0]),p.map(x=>x[1]));
    view('dot',NUM.length>=2,'O gráfico de pontos precisa de ao menos duas colunas numéricas (ou faixas).');
    if(NUM.length>=2){if(num)$$('sx').value=G;if($$('sx').value==$$('sy').value)$$('sy').value=(NUM.find(x=>x[0]!=$$('sx').value)||NUM[0])[0];dot()}
    if(D.days.length){view('line',true);const l=ch.cline;l.data.labels=D.days.map(d=>d[0].slice(8)+'/'+d[0].slice(5,7));l.data.datasets[0].label='Respostas por dia';l.data.datasets[0].data=D.days.map(d=>d[1]);l.update()}
    else if(c.t=='n'){view('line',true);const l=ch.cline;l.data.labels=c.num.map((_,i)=>i+1);l.data.datasets[0].label=c.name;l.data.datasets[0].data=c.num;l.update()}
    else view('line',false,'Sem coluna de data no arquivo. Escolha uma variável numérica para ver os valores por ordem de resposta.');
    view('ogv',num,'A ogiva exige dados numéricos. Escolha uma variável numérica ou de faixas no filtro.');
    if(num){const a=c.cls;let s=0;setC('cogv',[a[0].L,...a.map(x=>x.U)].map(f2),[0,...a.map(x=>s+=x.f)])}
    blk();view('box',num,'O boxplot exige dados numéricos. Escolha uma variável numérica ou de faixas no filtro.');if(num)box();
    view('su',c.t=='n','Escolha uma variável numérica no filtro para ver estas medidas.');if(c.t=='n')$$('kun').innerHTML=kpis(sU(nn(c.num)));
    view('sg',num,'Escolha uma variável numérica ou de faixas no filtro para ver estas medidas.');
    if(num){let F=0;$$('kgr').innerHTML=kpis(sG(c.cls));$$('tgr').innerHTML=`<table><tr><th>Classe</th><th>Freq. (fi)</th><th>Acum. (Fi)</th></tr>${c.cls.map(x=>`<tr><td>${x.l}</td><td>${x.f}</td><td>${F+=x.f}</td></tr>`).join('')}</table>`}}
  $$('gf').onchange=upd;$$('sx').onchange=$$('sy').onchange=dot;$$('sgrp').onchange=()=>K[G].t!='c'&&box();upd();

  /* --- escolha do gráfico (um por vez) --- */
  const PN=['Barra','Pizza','Ponto','Linha','Ogiva','Blockspot','Caixa','Medidas sem classe','Medidas com classe'],ID=['bar','pie','dot','line','ogv','blk','box','su','sg'],
  CV={bar:'cbar',pie:'cpie',dot:'cdot',line:'cline',ogv:'cogv',box:'cbox'};
  function pick(i){ID.forEach((k,j)=>$$('cd_'+k).hidden=j!=i);document.querySelectorAll('#pk button').forEach((b,j)=>b.classList.toggle('on',j==i));if(CV[ID[i]]){const c=ch[CV[ID[i]]];c.resize();c.update('none')}}
  $$('pk').innerHTML=PN.map((n,i)=>`<button data-i="${i}">${n}</button>`).join('');
  $$('pk').onclick=e=>{const b=e.target.closest('button');if(b)pick(+b.dataset.i)};pick(0);

  /* ---------- 5. Downloads ---------- */
  const rep=(t,f,rows,c)=>R.push({t,f,rows,c}),
  catRows=()=>[['Variável','Categoria / classe','Frequência']].concat(K.flatMap(c=>freqOf(c).map(x=>[c.name,...x]))),
  stRows=()=>[['Variável','n','Mínimo','Q1','Mediana','Q3','Máximo','Média','Moda']].concat(K.filter(c=>c.t!='c').map(c=>{const s=sU(nn(c.num));return[c.name,s.n,s.min,s.q1,s.med,s.q3,s.max,+s.mean.toFixed(3),s.mode]}));
  rep('Barras','barras',catRows,'cbar');rep('Pizza','pizza',catRows,'cpie');
  rep('Ponto','ponto',()=>[['Resposta',...NUM.map(x=>x[1].name)]].concat(Array.from({length:D.n},(_,i)=>[i+1,...NUM.map(x=>x[1].num[i]??'')])),'cdot');
  rep('Linha','linha',()=>D.days.length?[['Data','Respostas']].concat(D.days):[['Resposta',...K.filter(c=>c.t=='n').map(c=>c.name)]].concat(Array.from({length:D.n},(_,i)=>[i+1,...K.filter(c=>c.t=='n').map(c=>c.num[i]??'')])),'cline');
  rep('Ogiva','ogiva',()=>{const o=[['Variável','Limite superior','Frequência acumulada']];K.filter(c=>c.t!='c').forEach(c=>{let s=0;c.cls.forEach(x=>o.push([c.name,x.U,s+=x.f]))});return o},'cogv');
  rep('Blockspot','blockspot',()=>BLK,null);rep('Caixa (boxplot)','caixa',stRows,'cbox');
  rep('Medidas sem intervalo de classe','medidas_sem_classe',stRows,null);
  rep('Medidas com intervalo de classe','medidas_com_classe',()=>[['Variável','n','Média','Mediana','Moda','Classe modal','Q1','Q2','Q3']].concat(K.filter(c=>c.t!='c').map(c=>{const s=sG(c.cls);return[c.name,s.n,s.mean,s.med,s.mode,s.cls,s.q1,s.med,s.q3].map(v=>typeof v=='number'?+v.toFixed(3):v)})),null);
  const dl=(n,t,m)=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:m}));a.download=n;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)},
  csv=r=>'\ufeff'+r.map(x=>x.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(';')).join('\r\n'),
  getCsv=r=>dl(r.f+'.csv',csv(r.rows()),'text/csv;charset=utf-8');
  $$('down').innerHTML=`<section class="card wide dl"><h2>Baixar dados de todos os gráficos</h2><div><button class="btn b" id="all">Todos os CSV</button></div></section>`+
    R.map((r,i)=>`<section class="card dl"><h2>${r.t}</h2><div><button class="btn" data-c="${i}">CSV</button>${r.c?`<button class="btn b" data-p="${i}">PNG</button>`:''}</div></section>`).join('');
  $$('down').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.id=='all')R.forEach((r,i)=>setTimeout(()=>getCsv(r),i*250));
    else if(b.dataset.c)getCsv(R[b.dataset.c]);else if(b.dataset.p){const r=R[b.dataset.p],a=document.createElement('a');a.href=ch[r.c].toBase64Image('image/png',1);a.download=r.f+'.png';a.click()}};
}
boot();

/* ---------- 6. Abas e carregamento de arquivos ---------- */
const TB={dash:['dash','flt'],down:['down'],up:['up']};
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('on',x==b));
  ['dash','flt','down','up'].forEach(id=>$$(id).hidden=!TB[b.dataset.t].includes(id)||(id=='flt'&&!D))});
const ust=(m,e)=>{$$('ust').textContent=m;$$('ust').classList.toggle('err',!!e)},
csvParse=tx=>{tx=tx.replace(/^\ufeff/,'');const l1=tx.split(/\r?\n/)[0].replace(/"[^"]*"/g,''),
  sep=[';',',','\t'].map(s=>[s,l1.split(s).length]).sort((a,b)=>b[1]-a[1])[0][0],out=[];let r=[],f='',qo=0;
  for(let i=0;i<tx.length;i++){const c=tx[i];if(qo){if(c=='"'){if(tx[i+1]=='"'){f+='"';i++}else qo=0}else f+=c}
  else if(c=='"')qo=1;else if(c==sep){r.push(f);f=''}else if(c=='\n'||c=='\r'){if(c=='\r'&&tx[i+1]=='\n')i++;r.push(f);out.push(r);r=[];f=''}else f+=c}
  if(f||r.length){r.push(f);out.push(r)}return out};
async function load(file){if(!file)return;
  try{const ext=file.name.split('.').pop().toLowerCase();let a;
    if(ext=='csv'||ext=='txt')a=csvParse(await file.text());
    else if(['xlsx','xlsm','xls'].includes(ext)){const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true});a=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,raw:true,defval:''})}
    else throw new Error('Formato não aceito. Envie um arquivo .xlsx, .xls ou .csv.');
    const d=analyze(a);D=d;
    try{boot()}catch(e){D=null;boot();throw new Error('Não foi possível montar os gráficos com este arquivo ('+e.message+').')}
    const k=t=>d.cols.filter(c=>c.t==t).length;
    ust(`Arquivo "${file.name}" carregado: ${d.n} respostas e ${d.cols.length} colunas reconhecidas (${k('c')} de categorias, ${k('n')} numéricas, ${k('g')} de faixas${d.days.length?', 1 de data':''}).`);$$('ver').hidden=false}
  catch(e){ust(e.message,1)}}
const fi=$$('file'),dp=$$('drop');
fi.onchange=()=>{load(fi.files[0]);fi.value=''};
dp.onkeydown=e=>{if(e.key=='Enter'||e.key==' '){e.preventDefault();fi.click()}};
['dragenter','dragover'].forEach(n=>dp.addEventListener(n,e=>{e.preventDefault();dp.classList.add('ov')}));
['dragleave','drop'].forEach(n=>dp.addEventListener(n,e=>{e.preventDefault();dp.classList.remove('ov')}));
dp.addEventListener('drop',e=>load(e.dataTransfer.files[0]));
$$('rst').onclick=()=>{D=null;boot();$$('ver').hidden=true;ust('Dados removidos. Nenhum arquivo carregado.')};
$$('ver').onclick=()=>document.querySelector('nav button[data-t="dash"]').click();
$$('tpl').onclick=()=>{const t='\ufeffData;Departamento;Nota do atendimento (1 a 5);Tempo de espera;Velocidade da internet (Mbps)\r\n15/10/2026;Comercial;5;Entre 1 a 15 minutos;80\r\n16/10/2026;Financeiro;4;Entre 16 a 30 minutos;120\r\n',
  a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:'text/csv;charset=utf-8'}));a.download='modelo_dados.csv';a.click()};
if(!D)document.querySelector('nav button[data-t="up"]').click();
